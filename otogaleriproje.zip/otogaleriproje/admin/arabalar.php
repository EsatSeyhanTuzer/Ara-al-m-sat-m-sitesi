<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
adminGerekli();
$conn = baglan();
$mesaj = '';
if (isset($_GET['sil'])) {
    $sil_id = (int)$_GET['sil'];
    $conn->query("DELETE FROM cars WHERE id = $sil_id");
    $mesaj = '<div class="alert alert-success">Araç silindi.</div>';
}
$upload_dir = '../uploads/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $fields = ['marka','model','yil','km','fiyat','renk','yakit','vites','durum','aciklama'];
    $data   = [];
    foreach ($fields as $f) $data[$f] = trim($_POST[$f] ?? '');
    $resim = $id ? ($_POST['resim_mevcut'] ?? 'default.jpg') : 'default.jpg';
    if (!empty($_FILES['resim']['name'])) {
        $uzanti  = strtolower(pathinfo($_FILES['resim']['name'], PATHINFO_EXTENSION));
        $izinli  = ['jpg','jpeg','png','webp'];
        if (in_array($uzanti, $izinli) && $_FILES['resim']['size'] < 5 * 1024 * 1024) {
            $yeni_ad = 'arac_' . time() . '_' . rand(100,999) . '.' . $uzanti;
            if (move_uploaded_file($_FILES['resim']['tmp_name'], $upload_dir . $yeni_ad)) {
                $resim = $yeni_ad;
            }
        }
    }

    if ($id) {
        $stmt = $conn->prepare("UPDATE cars SET marka=?,model=?,yil=?,km=?,fiyat=?,renk=?,yakit=?,vites=?,durum=?,aciklama=?,resim=? WHERE id=?");
        $stmt->bind_param('ssiidssssssi', $data['marka'],$data['model'],$data['yil'],$data['km'],$data['fiyat'],$data['renk'],$data['yakit'],$data['vites'],$data['durum'],$data['aciklama'],$resim,$id);
    } else {
        $stmt = $conn->prepare("INSERT INTO cars (marka,model,yil,km,fiyat,renk,yakit,vites,durum,aciklama,resim) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
        $stmt->bind_param('ssiidssssss', $data['marka'],$data['model'],$data['yil'],$data['km'],$data['fiyat'],$data['renk'],$data['yakit'],$data['vites'],$data['durum'],$data['aciklama'],$resim);
    }
    $stmt->execute();
    $mesaj = '<div class="alert alert-success">' . ($id ? 'Araç güncellendi.' : 'Araç eklendi.') . '</div>';
}
$duzenle = null;
if (isset($_GET['duzenle'])) {
    $stmt = $conn->prepare("SELECT * FROM cars WHERE id=?");
    $stmt->bind_param('i', $_GET['duzenle']);
    $stmt->execute();
    $duzenle = $stmt->get_result()->fetch_assoc();
}
$arabalar = $conn->query("
    SELECT c.*, COUNT(t.id) as talep_sayisi
    FROM cars c
    LEFT JOIN talepler t ON t.car_id = c.id
    GROUP BY c.id
    ORDER BY c.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Araç Yönetimi | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --kirmizi: #e63946; --koyu: #1a1a2e; }
        body { background: #f0f2f5; }
        .sidebar { width:240px; min-height:100vh; background:var(--koyu); position:fixed; top:0; left:0; z-index:100; }
        .sidebar .nav-link { color:rgba(255,255,255,.7); padding:10px 20px; border-radius:8px; margin:2px 10px; }
        .sidebar .nav-link:hover,.sidebar .nav-link.active { background:var(--kirmizi); color:white; }
        .sidebar .nav-link i { width:20px; }
        .main-content { margin-left:240px; }
    </style>
</head>
<body>
<div class="sidebar py-3">
    <div class="text-center mb-4 px-3">
        <i class="fas fa-car fa-2x" style="color:var(--kirmizi)"></i>
        <div class="text-white fw-bold mt-1">OtoGaleri Admin</div>
    </div>
    <ul class="nav flex-column">
        <li><a href="index.php" class="nav-link"><i class="fas fa-tachometer-alt me-2"></i>Kontrol Paneli</a></li>
        <li><a href="arabalar.php" class="nav-link active"><i class="fas fa-car me-2"></i>Araçlar</a></li>
        <li><a href="talepler.php" class="nav-link"><i class="fas fa-clipboard-list me-2"></i>Gelen Kutusu</a></li>
        <li><a href="satislar.php" class="nav-link"><i class="fas fa-hand-holding-usd me-2"></i>Satışlar</a></li>
        <li><a href="istatistik.php" class="nav-link"><i class="fas fa-chart-bar me-2"></i>İstatistikler</a></li>
        <li class="mt-3"><hr style="border-color:rgba(255,255,255,.1)"></li>
        <li><a href="../index.php" class="nav-link"><i class="fas fa-globe me-2"></i>Siteyi Gör</a></li>
        <li><a href="../logout.php" class="nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
    </ul>
</div>

<div class="main-content p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="fw-bold">🚗 Araç Yönetimi</h4>
        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#aracModal">
            <i class="fas fa-plus me-2"></i>Yeni Araç Ekle
        </button>
    </div>

    <?= $mesaj ?>

    <div class="bg-white rounded-3 shadow-sm">
        <table class="table table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>#</th><th>Araç</th><th>Yıl</th><th>KM</th>
                    <th>Fiyat</th><th>Durum</th><th class="text-center">Tıklanma</th>
                    <th class="text-center">Talep</th><th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($arabalar as $a): ?>
                <tr>
                    <td><?= $a['id'] ?></td>
                    <td>
                        <strong><?= htmlspecialchars($a['marka'].' '.$a['model']) ?></strong>
                        <small class="text-muted d-block"><?= $a['yakit'] ?> / <?= $a['vites'] ?></small>
                    </td>
                    <td><?= $a['yil'] ?></td>
                    <td><?= number_format($a['km']) ?></td>
                    <td class="fw-bold text-danger"><?= paraFormat($a['fiyat']) ?></td>
                    <td>
                        <?php $sc = ['Satışta'=>'success','Satıldı'=>'secondary','Rezerve'=>'warning']; ?>
                        <span class="badge bg-<?= $sc[$a['durum']] ?? 'secondary' ?>"><?= $a['durum'] ?></span>
                    </td>
                    <td class="text-center"><span class="badge bg-info text-dark"><?= $a['tiklanma'] ?></span></td>
                    <td class="text-center"><span class="badge bg-primary"><?= $a['talep_sayisi'] ?></span></td>
                    <td>
                        <a href="arabalar.php?duzenle=<?= $a['id'] ?>" class="btn btn-sm btn-outline-primary me-1">
                            <i class="fas fa-edit"></i>
                        </a>
                        <a href="../arac_detay.php?id=<?= $a['id'] ?>" target="_blank" class="btn btn-sm btn-outline-secondary me-1">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="arabalar.php?sil=<?= $a['id'] ?>" class="btn btn-sm btn-outline-danger"
                           onclick="return confirm('Bu aracı silmek istediğinize emin misiniz?')">
                            <i class="fas fa-trash"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="modal fade" id="aracModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--koyu);">
                <h5 class="modal-title text-white">
                    <?= $duzenle ? 'Aracı Düzenle' : 'Yeni Araç Ekle' ?>
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <?php if ($duzenle): ?>
                    <input type="hidden" name="id" value="<?= $duzenle['id'] ?>">
                    <input type="hidden" name="resim_mevcut" value="<?= htmlspecialchars($duzenle['resim'] ?? 'default.jpg') ?>">
                <?php endif; ?>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Marka</label>
                            <input type="text" name="marka" class="form-control" required
                                   value="<?= htmlspecialchars($duzenle['marka'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Model</label>
                            <input type="text" name="model" class="form-control" required
                                   value="<?= htmlspecialchars($duzenle['model'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Yıl</label>
                            <input type="number" name="yil" class="form-control" min="1990" max="2026" required
                                   value="<?= $duzenle['yil'] ?? date('Y') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Kilometre</label>
                            <input type="number" name="km" class="form-control" required
                                   value="<?= $duzenle['km'] ?? 0 ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Fiyat (₺)</label>
                            <input type="number" name="fiyat" class="form-control" step="0.01" required
                                   value="<?= $duzenle['fiyat'] ?? '' ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Renk</label>
                            <input type="text" name="renk" class="form-control"
                                   value="<?= htmlspecialchars($duzenle['renk'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Yakıt</label>
                            <select name="yakit" class="form-select">
                                <?php foreach (['Benzin','Dizel','Elektrik','Hibrit','LPG'] as $y): ?>
                                    <option <?= ($duzenle['yakit'] ?? '') === $y ? 'selected' : '' ?>><?= $y ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Vites</label>
                            <select name="vites" class="form-select">
                                <?php foreach (['Manuel','Otomatik','Yarı Otomatik'] as $v): ?>
                                    <option <?= ($duzenle['vites'] ?? '') === $v ? 'selected' : '' ?>><?= $v ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Durum</label>
                            <select name="durum" class="form-select">
                                <?php foreach (['Satışta','Rezerve','Satıldı'] as $d): ?>
                                    <option <?= ($duzenle['durum'] ?? 'Satışta') === $d ? 'selected' : '' ?>><?= $d ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Araç Görseli</label>
                            <?php if (!empty($duzenle['resim']) && $duzenle['resim'] !== 'default.jpg'): ?>
                                <div class="mb-2">
                                    <img src="../uploads/<?= htmlspecialchars($duzenle['resim']) ?>" 
                                         style="height:60px; border-radius:6px; object-fit:cover;">
                                    <small class="text-muted ms-2">Mevcut görsel</small>
                                </div>
                            <?php endif; ?>
                            <input type="file" name="resim" class="form-control" accept="image/jpeg,image/png,image/webp">
                            <small class="text-muted">JPG, PNG, WEBP — max 5MB</small>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Açıklama</label>
                            <textarea name="aciklama" class="form-control" rows="3"><?= htmlspecialchars($duzenle['aciklama'] ?? '') ?></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-danger">
                        <i class="fas fa-save me-1"></i><?= $duzenle ? 'Güncelle' : 'Kaydet' ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<?php if ($duzenle): ?>
<script>
    const modal = new bootstrap.Modal(document.getElementById('aracModal'));
    modal.show();
</script>
<?php endif; ?>
</body>
</html>