<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
adminGerekli();

$conn = baglan();
$stats = $conn->query("
    SELECT
        (SELECT COUNT(*) FROM cars WHERE durum='Satışta')  as satistaki,
        (SELECT COUNT(*) FROM cars WHERE durum='Satıldı')  as satilan,
        (SELECT COUNT(*) FROM cars WHERE durum='Rezerve')  as rezerve,
        (SELECT COUNT(*) FROM talepler WHERE durum='Bekliyor') as bekleyen_talep,
        (SELECT COUNT(*) FROM talepler) as toplam_talep,
        (SELECT COALESCE(SUM(satis_fiyati),0) FROM satislar) as toplam_ciro,
        (SELECT SUM(tiklanma) FROM cars) as toplam_tiklanma
")->fetch_assoc();
$populer = $conn->query("SELECT id, marka, model, yil, tiklanma, fiyat, durum FROM cars ORDER BY tiklanma DESC LIMIT 5")->fetch_all(MYSQLI_ASSOC);
$son_talepler = $conn->query("
    SELECT t.*, c.marka, c.model, c.yil
    FROM talepler t 
    JOIN cars c ON t.car_id = c.id 
    ORDER BY t.created_at DESC LIMIT 8
")->fetch_all(MYSQLI_ASSOC);
$oran = $conn->query("
    SELECT c.id, c.marka, c.model, c.tiklanma,
           COUNT(t.id) as talep_sayisi,
           ROUND(COUNT(t.id)/NULLIF(c.tiklanma,0)*100,1) as donusum
    FROM cars c
    LEFT JOIN talepler t ON t.car_id = c.id
    GROUP BY c.id
    ORDER BY donusum DESC
    LIMIT 5
")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Panel | Oto Galeri</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --kirmizi: #e63946; --koyu: #1a1a2e; }
        body { background: #f0f2f5; }
        .sidebar { width: 240px; min-height: 100vh; background: var(--koyu); position:fixed; top:0; left:0; z-index:100; }
        .sidebar .nav-link { color: rgba(255,255,255,.7); padding: 10px 20px; border-radius: 8px; margin: 2px 10px; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background: var(--kirmizi); color: white; }
        .sidebar .nav-link i { width: 20px; }
        .main-content { margin-left: 240px; }
        .stat-card { border: none; border-radius: 12px; }
        .stat-icon { width: 50px; height: 50px; border-radius: 10px; display:flex; align-items:center; justify-content:center; font-size: 1.3rem; }
        .table-card { border: none; border-radius: 12px; box-shadow: 0 2px 10px rgba(0,0,0,.07); }
        .badge-bekliyor  { background: #ffc107; color: #000; }
        .badge-gorusuluyor { background: #0d6efd; }
        .badge-satildi   { background: #198754; }
        .badge-iptal     { background: #6c757d; }
    </style>
</head>
<body>
<div class="sidebar py-3">
    <div class="text-center mb-4 px-3">
        <i class="fas fa-car fa-2x" style="color:var(--kirmizi)"></i>
        <div class="text-white fw-bold mt-1">OtoGaleri Admin</div>
    </div>
    <ul class="nav flex-column">
        <li><a href="index.php" class="nav-link active"><i class="fas fa-tachometer-alt me-2"></i>Kontrol Paneli</a></li>
        <li><a href="arabalar.php" class="nav-link"><i class="fas fa-car me-2"></i>Araçlar</a></li>
        <li><a href="talepler.php" class="nav-link"><i class="fas fa-clipboard-list me-2"></i>Gelen Kutusu</a></li>
        <li><a href="satislar.php" class="nav-link"><i class="fas fa-hand-holding-usd me-2"></i>Satışlar</a></li>
        <li><a href="istatistik.php" class="nav-link"><i class="fas fa-chart-bar me-2"></i>İstatistikler</a></li>
        <li class="mt-3"><hr style="border-color:rgba(255,255,255,.1)"></li>
        <li><a href="../index.php" class="nav-link"><i class="fas fa-globe me-2"></i>Siteyi Gör</a></li>
        <li><a href="../logout.php" class="nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
    </ul>
</div>
<div class="main-content p-4">
    <h4 class="fw-bold mb-4">Kontrol Paneli</h4>
    <div class="row g-3 mb-4">
        <?php $kartlar = [
            ['label'=>'Satışta Araç',   'deger'=>$stats['satistaki'],       'icon'=>'fa-car',              'renk'=>'#e63946','bg'=>'#fde8ea'],
            ['label'=>'Satılan Araç',   'deger'=>$stats['satilan'],         'icon'=>'fa-check-circle',     'renk'=>'#198754','bg'=>'#d1f0de'],
            ['label'=>'Bekleyen Talep', 'deger'=>$stats['bekleyen_talep'],  'icon'=>'fa-clipboard-list',   'renk'=>'#ffc107','bg'=>'#fff3cd'],
            ['label'=>'Toplam Ciro',    'deger'=>paraFormat($stats['toplam_ciro']), 'icon'=>'fa-lira-sign','renk'=>'#0d6efd','bg'=>'#dce8ff'],
            ['label'=>'Toplam Tıklanma','deger'=>$stats['toplam_tiklanma'], 'icon'=>'fa-eye',              'renk'=>'#6f42c1','bg'=>'#ede8ff'],
            ['label'=>'Toplam Talep',   'deger'=>$stats['toplam_talep'],    'icon'=>'fa-users',            'renk'=>'#20c997','bg'=>'#d3f9ee'],
        ]; ?>
        <?php foreach ($kartlar as $k): ?>
        <div class="col-6 col-md-4 col-xl-2">
            <div class="stat-card bg-white p-3 shadow-sm text-center">
                <div class="stat-icon mx-auto mb-2" style="background:<?= $k['bg'] ?>; color:<?= $k['renk'] ?>">
                    <i class="fas <?= $k['icon'] ?>"></i>
                </div>
                <div class="fw-bold fs-5" style="color:<?= $k['renk'] ?>"><?= $k['deger'] ?></div>
                <small class="text-muted"><?= $k['label'] ?></small>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="row g-4">
        <div class="col-lg-6">
            <div class="table-card bg-white p-4">
                <h6 class="fw-bold mb-3"><i class="fas fa-fire text-danger me-2"></i>En Çok Görüntülenen</h6>
                <table class="table table-sm table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Araç</th><th>Durum</th><th class="text-end">Tıklanma</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($populer as $p): ?>
                        <tr>
                            <td>
                                <a href="../arac_detay.php?id=<?= $p['id'] ?>" class="text-decoration-none fw-semibold">
                                    <?= htmlspecialchars($p['marka'].' '.$p['model']) ?>
                                </a>
                                <small class="text-muted d-block"><?= $p['yil'] ?> — <?= paraFormat($p['fiyat']) ?></small>
                            </td>
                            <td><span class="badge bg-<?= $p['durum']==='Satışta'?'success':'secondary' ?>"><?= $p['durum'] ?></span></td>
                            <td class="text-end fw-bold"><?= $p['tiklanma'] ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="table-card bg-white p-4">
                <h6 class="fw-bold mb-3"><i class="fas fa-percent text-primary me-2"></i>Tıklanma → Talep Dönüşümü</h6>
                <table class="table table-sm table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Araç</th><th class="text-center">Tıklanma</th><th class="text-center">Talep</th><th class="text-center">Oran</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($oran as $o): ?>
                        <tr>
                            <td class="fw-semibold"><?= htmlspecialchars($o['marka'].' '.$o['model']) ?></td>
                            <td class="text-center"><?= $o['tiklanma'] ?></td>
                            <td class="text-center"><?= $o['talep_sayisi'] ?></td>
                            <td class="text-center">
                                <span class="badge bg-<?= ($o['donusum'] ?? 0) > 10 ? 'success' : 'warning text-dark' ?>">
                                    %<?= $o['donusum'] ?? 0 ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-12">
            <div class="table-card bg-white p-4">
                <div class="d-flex justify-content-between mb-3">
                    <h6 class="fw-bold mb-0"><i class="fas fa-clipboard-list text-warning me-2"></i>Son Talepler</h6>
                    <a href="talepler.php" class="btn btn-sm btn-outline-danger">Tümünü Gör</a>
                </div>
                <table class="table table-sm table-hover mb-0">
                    <thead class="table-light">
                        <tr><th>Müşteri</th><th>Araç</th><th>Telefon</th><th>Durum</th><th>Tarih</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($son_talepler as $t): ?>
                        <tr>
                            <td class="fw-semibold"><?= htmlspecialchars($t['musteri_ad']) ?></td>
                            <td><?= htmlspecialchars($t['marka'].' '.$t['model'].' ('.$t['yil'].')') ?></td>
                            <td><a href="tel:<?= $t['musteri_tel'] ?>"><?= htmlspecialchars($t['musteri_tel']) ?></a></td>
                            <td>
                                <?php $durum_map = ['Bekliyor'=>'badge-bekliyor','Görüşülüyor'=>'badge-gorusuluyor text-white','Satıldı'=>'badge-satildi text-white','İptal'=>'badge-iptal text-white']; ?>
                                <span class="badge <?= $durum_map[$t['durum']] ?? 'bg-secondary' ?>"><?= $t['durum'] ?></span>
                            </td>
                            <td class="text-muted small"><?= date('d.m.Y H:i', strtotime($t['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>