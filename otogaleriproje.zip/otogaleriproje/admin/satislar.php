<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
adminGerekli();

$conn = baglan();
$mesaj = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $car_id      = (int)$_POST['car_id'];
    $talep_id    = (int)($_POST['talep_id'] ?? 0) ?: null;
    $satis_fiyat = (float)$_POST['satis_fiyati'];
    $satis_tarihi= $_POST['satis_tarihi'];
    $notlar      = trim($_POST['notlar'] ?? '');

    $stmt = $conn->prepare("INSERT INTO satislar (car_id, talep_id, satis_fiyati, satis_tarihi, notlar) VALUES (?,?,?,?,?)");
    $stmt->bind_param('iidss', $car_id, $talep_id, $satis_fiyat, $satis_tarihi, $notlar);
    $stmt->execute();

    $conn->query("UPDATE cars SET durum='Satıldı' WHERE id=$car_id");

    if ($talep_id) {
        $conn->query("UPDATE talepler SET durum='Satıldı' WHERE id=$talep_id");
    }
    $mesaj = '<div class="alert alert-success">Satış kaydedildi ve araç "Satıldı" olarak işaretlendi.</div>';
}

$satislar = $conn->query("
    SELECT s.*, c.marka, c.model, c.yil, c.fiyat as liste_fiyati,
           t.musteri_ad, t.musteri_tel
    FROM satislar s
    JOIN cars c ON s.car_id = c.id
    LEFT JOIN talepler t ON s.talep_id = t.id
    ORDER BY s.satis_tarihi DESC
")->fetch_all(MYSQLI_ASSOC);

$satistaki = $conn->query("SELECT id, marka, model, yil FROM cars WHERE durum='Satışta' OR durum='Rezerve' ORDER BY marka")->fetch_all(MYSQLI_ASSOC);

$bekleyen_talepler = $conn->query("SELECT id, musteri_ad, car_id FROM talepler WHERE durum IN ('Bekliyor','Görüşülüyor')")->fetch_all(MYSQLI_ASSOC);

$ciro = $conn->query("SELECT SUM(satis_fiyati) as toplam FROM satislar")->fetch_assoc()['toplam'] ?? 0;

$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Satışlar | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --kirmizi:#e63946; --koyu:#1a1a2e; }
        body { background:#f0f2f5; }
        .sidebar { width:240px; min-height:100vh; background:var(--koyu); position:fixed; top:0; left:0; z-index:100; }
        .sidebar .nav-link { color:rgb(255, 255, 255); padding:10px 20px; border-radius:8px; margin:2px 10px; }
        .sidebar .nav-link:hover,.sidebar .nav-link.active { background:var(--kirmizi); color:white; }
        .sidebar .nav-link i { width:20px; }
        .main-content { margin-left:240px; }
    </style>
</head>
<body>
<div class="sidebar py-3">
    <div class="text-center mb-4 px-3">
        <i class="fas fa-car fa-2x" style="color:var(--kirmizi)"></i>
        <div class="text-white fw-bold mt-1">OtoGaleri Admin</div>
    </div>
    <ul class="nav flex-column">
        <li><a href="index.php" class="nav-link"><i class="fas fa-tachometer-alt me-2"></i>Kontrol Paneli</a></li>
        <li><a href="arabalar.php" class="nav-link"><i class="fas fa-car me-2"></i>Araçlar</a></li>
        <li><a href="talepler.php" class="nav-link"><i class="fas fa-clipboard-list me-2"></i>Gelen Kutusu</a></li>
        <li><a href="satislar.php" class="nav-link active"><i class="fas fa-hand-holding-usd me-2"></i>Satışlar</a></li>
        <li><a href="istatistik.php" class="nav-link"><i class="fas fa-chart-bar me-2"></i>İstatistikler</a></li>
        <li class="mt-3"><hr style="border-color:rgba(255,255,255,.1)"></li>
        <li><a href="../index.php" class="nav-link"><i class="fas fa-globe me-2"></i>Siteyi Gör</a></li>
        <li><a href="../logout.php" class="nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
    </ul>
</div>

<div class="main-content p-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="fw-bold mb-0">💰 Satışlar</h4>
            <small class="text-muted">Toplam Ciro: <strong class="text-success"><?= paraFormat($ciro) ?></strong></small>
        </div>
        <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#satisModal">
            <i class="fas fa-plus me-2"></i>Satış Kaydet
        </button>
    </div>

    <?= $mesaj ?>

    <div class="bg-white rounded-3 shadow-sm overflow-hidden">
        <table class="table table-hover mb-0">
            <thead class="table-dark">
                <tr><th>#</th><th>Araç</th><th>Müşteri</th><th>Alış Fiyatı</th><th>Satış Fiyatı</th><th>Fark</th><th>Tarih</th><th>Notlar</th></tr>
            </thead>
            <tbody>
                <?php foreach ($satislar as $s): 
                    $fark = $s['satis_fiyati'] - $s['liste_fiyati'];
                ?>
                <tr>
                    <td><?= $s['id'] ?></td>
                    <td><strong><?= htmlspecialchars($s['marka'].' '.$s['model']) ?></strong> <small class="text-muted">(<?= $s['yil'] ?>)</small></td>
                    <td><?= $s['musteri_ad'] ? htmlspecialchars($s['musteri_ad']) : '<i class="text-muted">Kayıtsız</i>' ?></td>
                    <td class="text-muted"><?= paraFormat($s['liste_fiyati']) ?></td>
                    <td class="fw-bold text-success"><?= paraFormat($s['satis_fiyati']) ?></td>
                    <td>
                        <span class="badge bg-<?= $fark >= 0 ? 'success' : 'danger' ?>">
                            <?= $fark >= 0 ? '+' : '' ?><?= paraFormat(abs($fark)) ?>
                        </span>
                    </td>
                    <td><?= date('d.m.Y', strtotime($s['satis_tarihi'])) ?></td>
                    <td class="small text-muted"><?= htmlspecialchars($s['notlar'] ?? '—') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="modal fade" id="satisModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header" style="background:var(--koyu);">
                <h5 class="modal-title text-white">Satış Kaydet</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Araç</label>
                        <select name="car_id" class="form-select" required>
                            <option value="">— Araç Seçin —</option>
                            <?php foreach ($satistaki as $a): ?>
                                <option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['marka'].' '.$a['model'].' ('.$a['yil'].')') ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">İlgili Talep <small class="text-muted">(opsiyonel)</small></label>
                        <select name="talep_id" class="form-select">
                            <option value="">— Talep Yok —</option>
                            <?php foreach ($bekleyen_talepler as $t): ?>
                                <option value="<?= $t['id'] ?>"><?= $t['id'] ?> - <?= htmlspecialchars($t['musteri_ad']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Satış Fiyatı (₺)</label>
                        <input type="number" name="satis_fiyati" class="form-control" step="0.01" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Satış Tarihi</label>
                        <input type="date" name="satis_tarihi" class="form-control" value="<?= date('Y-m-d') ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notlar</label>
                        <textarea name="notlar" class="form-control" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-danger"><i class="fas fa-save me-1"></i>Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>