<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
adminGerekli();

$conn = baglan();
$mesaj = '';
if (isset($_GET['durum_guncelle']) && isset($_GET['id'])) {
    $tid    = (int)$_GET['id'];
    $durum  = $_GET['durum_guncelle'];
    $izin   = ['Bekliyor','Görüşülüyor','Satıldı','İptal'];
    if (in_array($durum, $izin)) {
        $conn->query("UPDATE talepler SET durum='$durum' WHERE id=$tid");
        $mesaj = '<div class="alert alert-success">Talep durumu güncellendi.</div>';
    }
}

$talepler = $conn->query("
    SELECT t.*, c.marka, c.model, c.yil, c.fiyat
    FROM talepler t
    JOIN cars c ON t.car_id = c.id
    ORDER BY t.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

$conn->close();

$durum_renk = ['Bekliyor'=>'warning text-dark','Görüşülüyor'=>'primary','Satıldı'=>'success','İptal'=>'secondary'];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Talepler | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --kirmizi:#e63946; --koyu:#1a1a2e; }
        body { background:#f0f2f5; }
        .sidebar { width:240px; min-height:100vh; background:var(--koyu); position:fixed; top:0; left:0; z-index:100; }
        .sidebar .nav-link { color:rgba(255,255,255,.7); padding:10px 20px; border-radius:8px; margin:2px 10px; }
        .sidebar .nav-link:hover,.sidebar .nav-link.active { background:var(--kirmizi); color:white; }
        .sidebar .nav-link i { width:20px; }
        .main-content { margin-left:240px; }
    </style>
</head>
<body>
<div class="sidebar py-3">
    <div class="text-center mb-4 px-3">
        <i class="fas fa-car fa-2x" style="color:var(--kirmizi)"></i>
        <div class="text-white fw-bold mt-1">OtoGaleri Admin</div>
    </div>
    <ul class="nav flex-column">
        <li><a href="index.php" class="nav-link"><i class="fas fa-tachometer-alt me-2"></i>Kontrol Paneli</a></li>
        <li><a href="arabalar.php" class="nav-link"><i class="fas fa-car me-2"></i>Araçlar</a></li>
        <li><a href="talepler.php" class="nav-link active"><i class="fas fa-clipboard-list me-2"></i>Gelen Kutusu</a></li>
        <li><a href="satislar.php" class="nav-link"><i class="fas fa-hand-holding-usd me-2"></i>Satışlar</a></li>
        <li><a href="istatistik.php" class="nav-link"><i class="fas fa-chart-bar me-2"></i>İstatistikler</a></li>
        <li class="mt-3"><hr style="border-color:rgba(255,255,255,.1)"></li>
        <li><a href="../index.php" class="nav-link"><i class="fas fa-globe me-2"></i>Siteyi Gör</a></li>
        <li><a href="../logout.php" class="nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
    </ul>
</div>

<div class="main-content p-4">
    <h4 class="fw-bold mb-4">📋 Talepler</h4>
    <?= $mesaj ?>

    <div class="bg-white rounded-3 shadow-sm overflow-hidden">
        <table class="table table-hover mb-0">
            <thead class="table-dark">
                <tr>
                    <th>#</th><th>Müşteri</th><th>Araç</th><th>Telefon</th>
                    <th>Mesaj</th><th>Durum</th><th>Tarih</th><th>İşlem</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($talepler as $t): ?>
                <tr>
                    <td><?= $t['id'] ?></td>
                    <td>
                        <strong><?= htmlspecialchars($t['musteri_ad']) ?></strong>
                        <?php if ($t['musteri_email']): ?>
                            <small class="text-muted d-block"><?= htmlspecialchars($t['musteri_email']) ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="../arac_detay.php?id=<?= $t['car_id'] ?>" target="_blank" class="text-decoration-none">
                            <?= htmlspecialchars($t['marka'].' '.$t['model']) ?> (<?= $t['yil'] ?>)
                        </a>
                        <small class="text-danger d-block"><?= paraFormat($t['fiyat']) ?></small>
                    </td>
                    <td><a href="tel:<?= $t['musteri_tel'] ?>"><?= htmlspecialchars($t['musteri_tel']) ?></a></td>
                    <td class="text-muted small" style="max-width:200px">
                        <?= $t['mesaj'] ? htmlspecialchars(mb_substr($t['mesaj'],0,60)) . (mb_strlen($t['mesaj'])>60?'…':'') : '<i>—</i>' ?>
                    </td>
                    <td><span class="badge bg-<?= $durum_renk[$t['durum']] ?? 'secondary' ?>"><?= $t['durum'] ?></span></td>
                    <td class="small text-muted"><?= date('d.m.Y H:i', strtotime($t['created_at'])) ?></td>
                    <td>
                        <div class="dropdown">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">Durum</button>
                            <ul class="dropdown-menu">
                                <?php foreach (['Bekliyor','Görüşülüyor','Satıldı','İptal'] as $d): ?>
                                <li>
                                    <a class="dropdown-item <?= $t['durum']===$d?'active':'' ?>"
                                       href="talepler.php?id=<?= $t['id'] ?>&durum_guncelle=<?= urlencode($d) ?>">
                                        <?= $d ?>
                                    </a>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>