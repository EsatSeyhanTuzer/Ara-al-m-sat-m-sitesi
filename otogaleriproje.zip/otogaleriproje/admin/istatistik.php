<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';
adminGerekli();

$conn = baglan();

$tiklanma_7gun = $conn->query("
    SELECT DATE(goruntuleme_tarihi) as gun, COUNT(*) as sayi
    FROM car_views
    WHERE goruntuleme_tarihi >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    GROUP BY DATE(goruntuleme_tarihi)
    ORDER BY gun ASC
")->fetch_all(MYSQLI_ASSOC);
$ilan_analiz = $conn->query("
    SELECT 
        c.id,
        c.marka,
        c.model,
        c.yil,
        c.durum,
        c.tiklanma,
        COUNT(DISTINCT t.id) as talep_sayisi,
        SUM(CASE WHEN t.durum='Satıldı' THEN 1 ELSE 0 END) as satilan_talep,
        (SELECT COUNT(*) FROM satislar WHERE car_id=c.id) as satis_var,
        ROUND(COUNT(DISTINCT t.id)/NULLIF(c.tiklanma,0)*100,1) as donusum_oran
    FROM cars c
    LEFT JOIN talepler t ON t.car_id = c.id
    GROUP BY c.id
    ORDER BY c.tiklanma DESC
")->fetch_all(MYSQLI_ASSOC);

$en_cok_talep = $conn->query("
    SELECT c.marka, c.model, c.yil, COUNT(t.id) as sayi
    FROM talepler t JOIN cars c ON t.car_id=c.id
    GROUP BY t.car_id ORDER BY sayi DESC LIMIT 5
")->fetch_all(MYSQLI_ASSOC);
$satis_kaynak = $conn->query("
    SELECT 
        SUM(CASE WHEN talep_id IS NOT NULL THEN 1 ELSE 0 END) as taleple,
        SUM(CASE WHEN talep_id IS NULL THEN 1 ELSE 0 END) as direk
    FROM satislar
")->fetch_assoc();

$conn->close();
$gunler  = array_column($tiklanma_7gun, 'gun');
$sayilar = array_column($tiklanma_7gun, 'sayi');
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>İstatistikler | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        :root { --kirmizi:#e63946; --koyu:#1a1a2e; }
        body { background:#f0f2f5; }
        .sidebar { width:240px; min-height:100vh; background:var(--koyu); position:fixed; top:0; left:0; z-index:100; }
        .sidebar .nav-link { color:rgba(255,255,255,.7); padding:10px 20px; border-radius:8px; margin:2px 10px; }
        .sidebar .nav-link:hover,.sidebar .nav-link.active { background:var(--kirmizi); color:white; }
        .sidebar .nav-link i { width:20px; }
        .main-content { margin-left:240px; }
        .chart-card { background:white; border-radius:12px; box-shadow:0 2px 10px rgba(0,0,0,.07); padding:20px; }
        .donusum-bar { height:8px; background:#e9ecef; border-radius:4px; }
        .donusum-fill { height:100%; border-radius:4px; background:var(--kirmizi); transition:width .5s; }
    </style>
</head>
<body>
<div class="sidebar py-3">
    <div class="text-center mb-4 px-3">
        <i class="fas fa-car fa-2x" style="color:var(--kirmizi)"></i>
        <div class="text-white fw-bold mt-1">OtoGaleri Admin</div>
    </div>
    <ul class="nav flex-column">
        <li><a href="index.php" class="nav-link"><i class="fas fa-tachometer-alt me-2"></i>Kontrol Paneli</a></li>
        <li><a href="arabalar.php" class="nav-link"><i class="fas fa-car me-2"></i>Araçlar</a></li>
        <li><a href="talepler.php" class="nav-link"><i class="fas fa-clipboard-list me-2"></i>Gelen Kutusu</a></li>
        <li><a href="satislar.php" class="nav-link"><i class="fas fa-hand-holding-usd me-2"></i>Satışlar</a></li>
        <li><a href="istatistik.php" class="nav-link active"><i class="fas fa-chart-bar me-2"></i>İstatistikler</a></li>
        <li class="mt-3"><hr style="border-color:rgba(255,255,255,.1)"></li>
        <li><a href="../index.php" class="nav-link"><i class="fas fa-globe me-2"></i>Siteyi Gör</a></li>
        <li><a href="../logout.php" class="nav-link text-danger"><i class="fas fa-sign-out-alt me-2"></i>Çıkış</a></li>
    </ul>
</div>

<div class="main-content p-4">
    <h4 class="fw-bold mb-4">📈 İstatistikler & Analiz</h4>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="chart-card">
                <h6 class="fw-bold mb-3"><i class="fas fa-eye text-primary me-2"></i>Son 7 Gün Görüntülenme</h6>
                <canvas id="tiklanmaGrafik" height="100"></canvas>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="chart-card">
                <h6 class="fw-bold mb-3"><i class="fas fa-chart-pie text-success me-2"></i>Satış Kaynağı</h6>
                <canvas id="satisKaynak" height="180"></canvas>
                <div class="mt-3 text-center">
                    <small class="text-muted">
                        Talepten: <strong><?= $satis_kaynak['taleple'] ?></strong> | 
                        Direk: <strong><?= $satis_kaynak['direk'] ?></strong>
                    </small>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="chart-card">
                <h6 class="fw-bold mb-3">
                    <i class="fas fa-table text-danger me-2"></i>
                    İlan Etkinlik Analizi
                    <small class="text-muted fw-normal ms-2">(Hangi ilana ne zaman kaç tıklandı, kaçı talebe dönüştü, satış sonuçlandı mı?)</small>
                </h6>
                <table class="table table-hover table-sm mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>Araç</th>
                            <th class="text-center">Durum</th>
                            <th class="text-center">Tıklanma</th>
                            <th class="text-center">Talep</th>
                            <th class="text-center">Satışla Sonuçlanan Talep</th>
                            <th class="text-center">Satış Var mı?</th>
                            <th style="min-width:150px">Dönüşüm Oranı</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ilan_analiz as $i): ?>
                        <tr>
                            <td>
                                <a href="../arac_detay.php?id=<?= $i['id'] ?>" target="_blank" class="text-decoration-none fw-semibold">
                                    <?= htmlspecialchars($i['marka'].' '.$i['model']) ?>
                                </a>
                                <small class="text-muted d-block"><?= $i['yil'] ?></small>
                            </td>
                            <td class="text-center">
                                <?php $sc=['Satışta'=>'success','Satıldı'=>'secondary','Rezerve'=>'warning']; ?>
                                <span class="badge bg-<?= $sc[$i['durum']] ?? 'secondary' ?>"><?= $i['durum'] ?></span>
                            </td>
                            <td class="text-center fw-bold"><?= $i['tiklanma'] ?></td>
                            <td class="text-center"><?= $i['talep_sayisi'] ?></td>
                            <td class="text-center">
                                <?php if ($i['satilan_talep'] > 0): ?>
                                    <span class="badge bg-success"><?= $i['satilan_talep'] ?> talep</span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if ($i['satis_var']): ?>
                                    <span class="badge bg-success"><i class="fas fa-check me-1"></i>Evet</span>
                                <?php else: ?>
                                    <span class="badge bg-light text-dark border">Hayır</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex align-items-center gap-2">
                                    <div class="donusum-bar flex-grow-1">
                                        <div class="donusum-fill" style="width:<?= min($i['donusum_oran'] ?? 0, 100) ?>%"></div>
                                    </div>
                                    <small class="fw-bold text-nowrap">%<?= $i['donusum_oran'] ?? 0 ?></small>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
const ctx1 = document.getElementById('tiklanmaGrafik').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: {
        labels: <?= json_encode($gunler) ?>,
        datasets: [{
            label: 'Günlük Görüntülenme',
            data: <?= json_encode($sayilar) ?>,
            borderColor: '#e63946',
            backgroundColor: 'rgba(230,57,70,.1)',
            tension: 0.4,
            fill: true,
            pointBackgroundColor: '#e63946',
            pointRadius: 5
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
            y: { beginAtZero: true, ticks: { stepSize: 1 } }
        }
    }
});
const ctx2 = document.getElementById('satisKaynak').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Talep Üzerinden', 'Direkt'],
        datasets: [{
            data: [<?= $satis_kaynak['taleple'] ?>, <?= $satis_kaynak['direk'] ?>],
            backgroundColor: ['#e63946', '#1a1a2e'],
            borderWidth: 0
        }]
    },
    options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' } }
    }
});
</script>
</body>
</html>