<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) { header('Location: index.php'); exit; }

$conn = baglan();
$stmt = $conn->prepare("SELECT * FROM cars WHERE id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$araba = $stmt->get_result()->fetch_assoc();

if (!$araba) { header('Location: index.php'); exit; }
tiklanmaKaydet($id, $conn);
$talep_sayisi = $conn->query("SELECT COUNT(*) as sayi FROM talepler WHERE car_id = $id")->fetch_assoc()['sayi'];
$satis_bilgisi = null;
if ($araba['durum'] === 'Satıldı') {
    $satis_bilgisi = $conn->query("SELECT * FROM satislar WHERE car_id = $id ORDER BY id DESC LIMIT 1")->fetch_assoc();
}
$mesaj_ok  = '';
$mesaj_err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $araba['durum'] === 'Satışta') {
    $ad    = trim($_POST['musteri_ad']  ?? '');
    $tel   = trim($_POST['musteri_tel'] ?? '');
    $email = trim($_POST['musteri_email'] ?? '');
    $not   = trim($_POST['mesaj'] ?? '');

    if ($ad && $tel) {
        $stmt2 = $conn->prepare("INSERT INTO talepler (car_id, musteri_ad, musteri_tel, musteri_email, mesaj) VALUES (?,?,?,?,?)");
        $stmt2->bind_param('issss', $id, $ad, $tel, $email, $not);
        if ($stmt2->execute()) {
            $mesaj_ok = 'Talebiniz alındı! Galeri ekibimiz en kısa sürede sizinle iletişime geçecektir.';
            $talep_sayisi++;
        } else {
            $mesaj_err = 'Bir hata oluştu, lütfen tekrar deneyin.';
        }
    } else {
        $mesaj_err = 'Ad Soyad ve Telefon alanları zorunludur.';
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($araba['marka'].' '.$araba['model']) ?> | Oto Galeri</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --kirmizi: #e63946; --koyu: #1a1a2e; }
        .araba-banner { height: 280px; background: linear-gradient(135deg, #1a1a2e, #16213e); 
                        display:flex; align-items:center; justify-content:center; border-radius:12px; }
        .araba-banner i { font-size: 8rem; color: rgba(255,255,255,.3); }
        .ozellik-badge { background: #f8f9fa; border-radius: 8px; padding: 10px 14px; text-align:center; }
        .fiyat-buyuk { color: var(--kirmizi); font-size: 2rem; font-weight: 800; }
        .talep-card { border: 2px solid var(--kirmizi); border-radius: 12px; }
        .btn-talep { background: var(--kirmizi); border: none; color: white; }
        .btn-talep:hover { background: #c1121f; color: white; }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark" style="background: var(--koyu);">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">
            <i class="fas fa-car me-2" style="color: var(--kirmizi)"></i>OtoGaleri
        </a>
        <div class="ms-auto">
            <?php if (girisYapildi()): ?>
                <?php if (adminMi()): ?>
                    <a href="admin/index.php" class="btn btn-sm btn-outline-warning me-2">Admin Panel</a>
                <?php endif; ?>
                <a href="logout.php" class="btn btn-sm btn-outline-light">Çıkış</a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm" style="background:var(--kirmizi);color:white;">Giriş Yap</a>
            <?php endif; ?>
        </div>
    </div>
</nav>

<div class="container py-4">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-danger">Ana Sayfa</a></li>
            <li class="breadcrumb-item active"><?= htmlspecialchars($araba['marka'].' '.$araba['model']) ?></li>
        </ol>
    </nav>

    <div class="row g-4">
        <div class="col-lg-8">
            <div class="bg-white rounded-3 shadow-sm p-4">
                <div class="mb-4">
                    <?php if (!empty($araba['resim']) && $araba['resim'] !== 'default.jpg'): ?>
                        <img src="uploads/<?= htmlspecialchars($araba['resim']) ?>"
                             style="width:100%; height:500px; object-fit:cover; border-radius:12px;">
                    <?php else: ?>
                        <div class="araba-banner"><i class="fas fa-car"></i></div>
                    <?php endif; ?>
                </div>

                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div>
                        <h2 class="fw-bold mb-1">
                            <?= htmlspecialchars($araba['marka'].' '.$araba['model']) ?>
                        </h2>
                        <span class="text-muted"><?= $araba['yil'] ?> Model</span>
                    </div>
                    <div class="text-end">
                        <?php
                        $durum_renk = match($araba['durum']) {
                            'Satışta' => 'success', 'Rezerve' => 'warning', 'Satıldı' => 'secondary', default => 'secondary'
                        };
                        ?>
                        <span class="badge bg-<?= $durum_renk ?> fs-6"><?= $araba['durum'] ?></span>
                    </div>
                </div>

                <div class="fiyat-buyuk mb-3"><?= paraFormat($araba['fiyat']) ?></div>
                <div class="row g-2 mb-4">
                    <?php $ozellikler = [
                        ['icon'=>'fa-road',      'label'=>'Kilometre',  'deger'=>number_format($araba['km']).' km'],
                        ['icon'=>'fa-gas-pump',  'label'=>'Yakıt',      'deger'=>$araba['yakit']],
                        ['icon'=>'fa-cog',       'label'=>'Vites',      'deger'=>$araba['vites']],
                        ['icon'=>'fa-palette',   'label'=>'Renk',       'deger'=>$araba['renk']],
                        ['icon'=>'fa-eye',       'label'=>'Görüntülenme','deger'=>$araba['tiklanma'].' kez'],
                        ['icon'=>'fa-clipboard', 'label'=>'Talep Sayısı','deger'=>$talep_sayisi.' talep'],
                    ]; ?>
                    <?php foreach ($ozellikler as $o): ?>
                    <div class="col-6 col-md-4">
                        <div class="ozellik-badge">
                            <div class="text-danger mb-1"><i class="fas <?= $o['icon'] ?>"></i></div>
                            <small class="text-muted d-block"><?= $o['label'] ?></small>
                            <strong><?= $o['deger'] ?></strong>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <?php if ($araba['aciklama']): ?>
                <div class="mb-3">
                    <h6 class="fw-bold">Açıklama</h6>
                    <p class="text-muted"><?= nl2br(htmlspecialchars($araba['aciklama'])) ?></p>
                </div>
                <?php endif; ?>

                <?php if ($satis_bilgisi): ?>
                <div class="alert alert-secondary">
                    <i class="fas fa-check-circle me-2"></i>
                    Bu araç <b><?= $satis_bilgisi['satis_tarihi'] ?></b> tarihinde 
                    <b><?= paraFormat($satis_bilgisi['satis_fiyati']) ?></b> fiyata satılmıştır.
                </div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="talep-card bg-white p-4">
                <h5 class="fw-bold mb-3">
                    <i class="fas fa-phone me-2 text-danger"></i>Talep Oluştur
                </h5>

                <?php if ($araba['durum'] !== 'Satışta'): ?>
                    <div class="alert alert-warning text-center">
                        <i class="fas fa-exclamation-triangle fa-2x mb-2 d-block"></i>
                        Bu araç şu an <b><?= $araba['durum'] ?></b> durumunda.<br>
                        Talep oluşturulamaz.
                    </div>
                <?php else: ?>
                    <?php if ($mesaj_ok): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i><?= $mesaj_ok ?>
                        </div>
                    <?php endif; ?>
                    <?php if ($mesaj_err): ?>
                        <div class="alert alert-danger">
                            <i class="fas fa-times-circle me-2"></i><?= $mesaj_err ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Ad Soyad <span class="text-danger">*</span></label>
                            <input type="text" name="musteri_ad" class="form-control" required
                                   value="<?= htmlspecialchars($_POST['musteri_ad'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Telefon <span class="text-danger">*</span></label>
                            <input type="tel" name="musteri_tel" class="form-control" required
                                   placeholder="05xx xxx xx xx"
                                   value="<?= htmlspecialchars($_POST['musteri_tel'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">E-posta</label>
                            <input type="email" name="musteri_email" class="form-control"
                                   value="<?= htmlspecialchars($_POST['musteri_email'] ?? '') ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Mesajınız</label>
                            <textarea name="mesaj" class="form-control" rows="3"
                                      placeholder="Test sürüşü, fiyat müzakeresi vs."><?= htmlspecialchars($_POST['mesaj'] ?? '') ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-talep w-100 fw-bold">
                            <i class="fas fa-paper-plane me-2"></i>Talep Gönder
                        </button>
                    </form>
                <?php endif; ?>

                <hr>
                <div class="text-center text-muted small">
                    <i class="fas fa-shield-alt me-1 text-success"></i>
                    Bilgileriniz güvende tutulur.
                </div>
            </div>

            <div class="bg-white rounded-3 shadow-sm p-3 mt-3 text-center">
                <a href="index.php" class="btn btn-outline-secondary w-100">
                    <i class="fas fa-arrow-left me-2"></i>Diğer Araçlara Dön
                </a>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>