<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

if (girisYapildi()) {
    header('Location: ' . (adminMi() ? 'admin/index.php' : 'index.php'));
    exit;
}

$hata = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $conn = baglan();
        $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username = ?");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id']  = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role']     = $user['role'];

                header('Location: ' . ($user['role'] === 'admin' ? 'admin/index.php' : 'index.php'));
                exit;
            }
        }
        $hata = 'Kullanıcı adı veya şifre hatalı.';
        $conn->close();
    } else {
        $hata = 'Lütfen tüm alanları doldurun.';
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Giriş Yap | Oto Galeri</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: #1a1a2e; min-height: 100vh; display: flex; align-items: center; }
        .login-card { background: #fff; border-radius: 16px; box-shadow: 0 20px 60px rgba(0,0,0,0.4); }
        .login-header { background: linear-gradient(135deg, #e63946, #c1121f); border-radius: 16px 16px 0 0; }
        .btn-giris { background: linear-gradient(135deg, #e63946, #c1121f); border: none; }
        .btn-giris:hover { background: linear-gradient(135deg, #c1121f, #a00); }
        .form-control:focus { border-color: #e63946; box-shadow: 0 0 0 0.2rem rgba(230,57,70,.25); }
    </style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5 col-lg-4">
            <div class="login-card">
                <div class="login-header text-white text-center py-4 px-4">
                    <i class="fas fa-car fa-3x mb-2"></i>
                    <h4 class="mb-0 fw-bold">Oto Galeri</h4>
                    <small class="opacity-75">Yönetim Sistemi</small>
                </div>
                <div class="p-4">
                    <?php if ($hata): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <i class="fas fa-exclamation-circle me-2"></i><?= htmlspecialchars($hata) ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Kullanıcı Adı</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" name="username" class="form-control" 
                                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required autofocus>
                            </div>
                        </div>
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Şifre</label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-giris text-white w-100 fw-bold py-2">
                            <i class="fas fa-sign-in-alt me-2"></i>Giriş Yap
                        </button>
                    </form>

                    <hr class="my-3">
                    <a href="index.php" class="btn btn-outline-secondary w-100">
                        <i class="fas fa-home me-2"></i>Misafir Olarak Devam Et
                    </a>

                    <div class="text-center mt-3">
                        <small class="text-muted">
                            Demo: <b>admin</b> / <b>password</b>
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>