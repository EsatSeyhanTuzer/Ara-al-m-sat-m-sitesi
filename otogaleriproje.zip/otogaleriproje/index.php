<?php
require_once 'includes/db.php';
require_once 'includes/auth.php';

$conn = baglan();
$marka_filtre = trim($_GET['marka'] ?? '');
$min_fiyat    = (int)($_GET['min_fiyat'] ?? 0);
$max_fiyat    = (int)($_GET['max_fiyat'] ?? 0);
$yakit_filtre = trim($_GET['yakit'] ?? '');
$vites_filtre = trim($_GET['vites'] ?? '');
$siralama     = $_GET['siralama'] ?? 'yeni';
$where = ["durum = 'Satışta'"];
$params = [];
$types  = '';

if ($marka_filtre) {
    $where[] = "marka = ?";
    $params[] = $marka_filtre;
    $types .= 's';
}
if ($min_fiyat > 0) {
    $where[] = "fiyat >= ?";
    $params[] = $min_fiyat;
    $types .= 'i';
}
if ($max_fiyat > 0) {
    $where[] = "fiyat <= ?";
    $params[] = $max_fiyat;
    $types .= 'i';
}
if ($yakit_filtre) {
    $where[] = "yakit = ?";
    $params[] = $yakit_filtre;
    $types .= 's';
}
if ($vites_filtre) {
    $where[] = "vites = ?";
    $params[] = $vites_filtre;
    $types .= 's';
}
$orderBy = match($siralama) {
    'fiyat_artan'  => 'fiyat ASC',
    'fiyat_azalan' => 'fiyat DESC',
    'populer'      => 'tiklanma DESC',
    default        => 'created_at DESC'
};
$sql = "SELECT * FROM cars WHERE " . implode(' AND ', $where) . " ORDER BY $orderBy";
$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$arabalar = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$markalar = $conn->query("SELECT DISTINCT marka FROM cars WHERE durum='Satışta' ORDER BY marka")->fetch_all(MYSQLI_ASSOC);
$istatistik = $conn->query("
    SELECT 
        COUNT(*) as toplam,
        SUM(tiklanma) as toplam_tiklanma,
        (SELECT COUNT(*) FROM talepler WHERE durum='Bekliyor') as bekleyen_talep
    FROM cars WHERE durum='Satışta'
")->fetch_assoc();
$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Oto Galeri - Araç Listesi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        :root { --kirmizi: #e63946; --koyu: #1a1a2e; }
        .navbar-brand span { color: var(--kirmizi); }
        .hero { background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: white; }
        .car-card { border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.08); 
                    transition: transform .2s, box-shadow .2s; overflow: hidden; }
        .car-card:hover { transform: translateY(-4px); box-shadow: 0 12px 30px rgba(0,0,0,.15); }
        .car-img { height: 200px; background: linear-gradient(135deg, #667eea, #764ba2); 
                   display:flex; align-items:center; justify-content:center; }
        .car-img i { font-size: 5rem; color: rgba(255,255,255,.7); }
        .badge-satis  { background: #28a745; }
        .badge-rezerve{ background: #ffc107; color: #000; }
        .fiyat { color: var(--kirmizi); font-size: 1.4rem; font-weight: 700; }
        .tiklanma { color: #6c757d; font-size: .8rem; }
        .filtre-card { border-radius: 12px; border: 1px solid #e9ecef; }
        .btn-ara { background: var(--kirmizi); border: none; color: white; }
        .btn-ara:hover { background: #c1121f; color: white; }
        .stat-box { background: white; border-radius: 10px; padding: 15px; text-align:center; 
                    box-shadow: 0 2px 8px rgba(0,0,0,.08); }
        .stat-num { font-size: 2rem; font-weight: 700; color: var(--kirmizi); }
    </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark" style="background: var(--koyu);">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">
            <i class="fas fa-car me-2" style="color: var(--kirmizi)"></i>
            Oto<span>Galeri</span>
        </a>
        <div class="ms-auto d-flex gap-2">
            <?php if (girisYapildi()): ?>
                <?php if (adminMi()): ?>
                    <a href="admin/index.php" class="btn btn-sm btn-outline-warning">
                        <i class="fas fa-cog me-1"></i>Admin Panel
                    </a>
                <?php endif; ?>
                <a href="logout.php" class="btn btn-sm btn-outline-light">
                    <i class="fas fa-sign-out-alt me-1"></i>Çıkış
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-sm" style="background:var(--kirmizi); color:white;">
                    <i class="fas fa-sign-in-alt me-1"></i>Giriş Yap
                </a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<div class="hero py-5">
    <div class="container">
        <h1 class="fw-bold mb-2">Hayalinizdeki Araç Burada</h1>
        <p class="opacity-75 mb-4">Güvenilir, kaliteli araçlar — tek bir çatı altında.</p>
        <div class="row g-3">
            <div class="col-md-3 col-6">
                <div class="stat-box">
                    <div class="stat-num"><?= $istatistik['toplam'] ?></div>
                    <small class="text-muted">Satışta Araç</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="stat-box">
                    <div class="stat-num"><?= $istatistik['toplam_tiklanma'] ?></div>
                    <small class="text-muted">Toplam Görüntülenme</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="stat-box">
                    <div class="stat-num"><?= $istatistik['bekleyen_talep'] ?></div>
                    <small class="text-muted">Aktif Talep</small>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container py-4">
    <div class="row g-4">
        <div class="col-lg-3">
            <div class="filtre-card bg-white p-3">
                <h6 class="fw-bold mb-3"><i class="fas fa-filter me-2 text-danger"></i>Filtrele</h6>
                <form method="GET">
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Marka</label>
                        <select name="marka" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            <?php foreach ($markalar as $m): ?>
                                <option value="<?= $m['marka'] ?>" <?= $marka_filtre === $m['marka'] ? 'selected' : '' ?>>
                                    <?= $m['marka'] ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Min Fiyat (₺)</label>
                        <input type="number" name="min_fiyat" class="form-control form-control-sm"
                               value="<?= $min_fiyat ?: '' ?>" placeholder="0">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Max Fiyat (₺)</label>
                        <input type="number" name="max_fiyat" class="form-control form-control-sm"
                               value="<?= $max_fiyat ?: '' ?>" placeholder="Sınırsız">
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Yakıt</label>
                        <select name="yakit" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            <?php foreach (['Benzin','Dizel','Elektrik','Hibrit','LPG'] as $y): ?>
                                <option value="<?= $y ?>" <?= $yakit_filtre === $y ? 'selected' : '' ?>><?= $y ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Vites</label>
                        <select name="vites" class="form-select form-select-sm">
                            <option value="">Tümü</option>
                            <?php foreach (['Manuel','Otomatik','Yarı Otomatik'] as $v): ?>
                                <option value="<?= $v ?>" <?= $vites_filtre === $v ? 'selected' : '' ?>><?= $v ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label small fw-semibold">Sırala</label>
                        <select name="siralama" class="form-select form-select-sm">
                            <option value="yeni" <?= $siralama==='yeni'?'selected':'' ?>>En Yeni</option>
                            <option value="fiyat_artan" <?= $siralama==='fiyat_artan'?'selected':'' ?>>Fiyat: Düşük → Yüksek</option>
                            <option value="fiyat_azalan" <?= $siralama==='fiyat_azalan'?'selected':'' ?>>Fiyat: Yüksek → Düşük</option>
                            <option value="populer" <?= $siralama==='populer'?'selected':'' ?>>En Popüler</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-ara w-100">
                        <i class="fas fa-search me-1"></i>Ara
                    </button>
                    <a href="index.php" class="btn btn-outline-secondary w-100 mt-2">Temizle</a>
                </form>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h6 class="text-muted mb-0"><?= count($arabalar) ?> araç listeleniyor</h6>
            </div>

            <?php if (empty($arabalar)): ?>
                <div class="text-center py-5">
                    <i class="fas fa-car-crash fa-4x text-muted mb-3"></i>
                    <h5 class="text-muted">Arama kriterlerinize uygun araç bulunamadı.</h5>
                    <a href="index.php" class="btn btn-outline-danger mt-2">Filtreleri Temizle</a>
                </div>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($arabalar as $araba): ?>
                    <div class="col-md-6 col-xl-4">
                        <div class="car-card bg-white h-100">
                            <div class="car-img position-relative">
                                <?php if (!empty($araba['resim']) && $araba['resim'] !== 'default.jpg'): ?>
                                    <img src="uploads/<?= htmlspecialchars($araba['resim']) ?>" 
                                         style="width:100%; height:200px; object-fit:cover;">
                                <?php else: ?>
                                    <i class="fas fa-car"></i>
                                <?php endif; ?>
                                <span class="badge badge-satis position-absolute top-0 end-0 m-2">
                                    <?= $araba['durum'] ?>
                                </span>
                            </div>
                            <div class="p-3">
                                <h6 class="fw-bold mb-1">
                                    <?= htmlspecialchars($araba['marka'] . ' ' . $araba['model']) ?>
                                    <small class="text-muted fw-normal">(<?= $araba['yil'] ?>)</small>
                                </h6>
                                <div class="d-flex gap-2 mb-2 flex-wrap">
                                    <span class="badge bg-light text-dark border">
                                        <i class="fas fa-road me-1"></i><?= number_format($araba['km']) ?> km
                                    </span>
                                    <span class="badge bg-light text-dark border">
                                        <i class="fas fa-gas-pump me-1"></i><?= $araba['yakit'] ?>
                                    </span>
                                    <span class="badge bg-light text-dark border">
                                        <i class="fas fa-cog me-1"></i><?= $araba['vites'] ?>
                                    </span>
                                </div>
                                <div class="fiyat mb-1"><?= paraFormat($araba['fiyat']) ?></div>
                                <div class="tiklanma mb-3">
                                    <i class="fas fa-eye me-1"></i><?= $araba['tiklanma'] ?> görüntülenme
                                </div>
                                <a href="arac_detay.php?id=<?= $araba['id'] ?>" class="btn btn-ara w-100">
                                    <i class="fas fa-info-circle me-1"></i>Detaylar
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<footer class="text-center py-4 mt-4 text-muted" style="background:#fff; border-top:1px solid #eee;">
    <small>Oto Galeri Yönetim Sistemi &copy; 2025 | Esat Seyhan Tüzer</small>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>