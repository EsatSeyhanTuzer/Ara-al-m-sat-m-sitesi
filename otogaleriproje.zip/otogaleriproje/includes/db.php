<?php

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // MySQL kullanıcı adınızı girin
define('DB_PASS', ''); 
define('DB_NAME', 'oto_galeri');

function baglan() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');

    if ($conn->connect_error) {
        die('<div style="padding:20px;background:#fee;color:#c00;font-family:sans-serif;">
            <h3>Veritabanı Bağlantı Hatası</h3>
            <p>' . $conn->connect_error . '</p>
            <p>Lütfen <b>includes/db.php</b> dosyasındaki bağlantı bilgilerini kontrol edin.</p>
        </div>');
    }

    return $conn;
}
?>