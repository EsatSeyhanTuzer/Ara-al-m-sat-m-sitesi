<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function girisYapildi() {
    return isset($_SESSION['user_id']);
}

function adminMi() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function adminGerekli() {
    if (!girisYapildi() || !adminMi()) {
        header('Location: ../login.php');
        exit;
    }
}

function girisGerekli() {
    if (!girisYapildi()) {
        header('Location: login.php');
        exit;
    }
}

function tiklanmaKaydet($car_id, $conn) {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $car_id = (int)$car_id;
    $kontrol = $conn->query("SELECT id FROM car_views 
        WHERE car_id = $car_id AND ip_adresi = '$ip' 
        AND goruntuleme_tarihi > DATE_SUB(NOW(), INTERVAL 1 HOUR)");

    if ($kontrol->num_rows === 0) {
        $conn->query("INSERT INTO car_views (car_id, ip_adresi) VALUES ($car_id, '$ip')");
        $conn->query("UPDATE cars SET tiklanma = tiklanma + 1 WHERE id = $car_id");
    }
}

function paraFormat($sayi) {
    return number_format($sayi, 0, ',', '.') . ' ₺';
}
?>